package net.mcreator.adminutilities.network;

import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.chat.Component;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.core.BlockPos;

import net.mcreator.adminutilities.procedures.WardenSpawnTrueButtonClickProcedure;
import net.mcreator.adminutilities.procedures.WardenSpawnFalseButtonClickProcedure;
import net.mcreator.adminutilities.procedures.TickUnfreezeButtonClickProcedure;
import net.mcreator.adminutilities.procedures.TickFreezeButtonClickProcedure;
import net.mcreator.adminutilities.procedures.ThunderButtonClickProcedure;
import net.mcreator.adminutilities.procedures.SurvivalButtonClickProcedure;
import net.mcreator.adminutilities.procedures.SuperSwordButtonClickProcedure;
import net.mcreator.adminutilities.procedures.SuperPickaxeButtonClickProcedure;
import net.mcreator.adminutilities.procedures.SpectatorButtonClickProcedure;
import net.mcreator.adminutilities.procedures.SpawnSculkPatchButtonClickProcedure;
import net.mcreator.adminutilities.procedures.RainyButtonClickProcedure;
import net.mcreator.adminutilities.procedures.NightButtonClickProcedure;
import net.mcreator.adminutilities.procedures.MobSpawningTrueButtonClickProcedure;
import net.mcreator.adminutilities.procedures.MobSpawningFalseButtonClickProcedure;
import net.mcreator.adminutilities.procedures.KeepInventoryTrueButtonClickProcedure;
import net.mcreator.adminutilities.procedures.KeepInventoryFalseButtonClickProcedure;
import net.mcreator.adminutilities.procedures.InvisibilityEffectButtonClickProcedure;
import net.mcreator.adminutilities.procedures.InstantHealthEffectButtonClickProcedure;
import net.mcreator.adminutilities.procedures.EnableRaidsButtonClickProcedure;
import net.mcreator.adminutilities.procedures.DisableRaidsButtonClickProcedure;
import net.mcreator.adminutilities.procedures.DayButtonClickProcedure;
import net.mcreator.adminutilities.procedures.CreativeButtonClickProcedure;
import net.mcreator.adminutilities.procedures.CommondBlockOutputTrueButtonClickProcedure;
import net.mcreator.adminutilities.procedures.CommondBlockOutputFalseButtonClickProcedure;
import net.mcreator.adminutilities.procedures.ClearWeatherButtonClickProcedure;
import net.mcreator.adminutilities.procedures.ClearEffectButtonClickProcedure;
import net.mcreator.adminutilities.procedures.ClearButtonClickProcedure;
import net.mcreator.adminutilities.procedures.AdventureButtonClickProcedure;
import net.mcreator.adminutilities.AdminUtilitiesMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public record AdminPanelButtonMessage(int buttonID, int x, int y, int z) implements CustomPacketPayload {

	public static final Type<AdminPanelButtonMessage> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath(AdminUtilitiesMod.MODID, "admin_panel_buttons"));
	public static final StreamCodec<RegistryFriendlyByteBuf, AdminPanelButtonMessage> STREAM_CODEC = StreamCodec.of((RegistryFriendlyByteBuf buffer, AdminPanelButtonMessage message) -> {
		buffer.writeInt(message.buttonID);
		buffer.writeInt(message.x);
		buffer.writeInt(message.y);
		buffer.writeInt(message.z);
	}, (RegistryFriendlyByteBuf buffer) -> new AdminPanelButtonMessage(buffer.readInt(), buffer.readInt(), buffer.readInt(), buffer.readInt()));
	@Override
	public Type<AdminPanelButtonMessage> type() {
		return TYPE;
	}

	public static void handleData(final AdminPanelButtonMessage message, final IPayloadContext context) {
		if (context.flow() == PacketFlow.SERVERBOUND) {
			context.enqueueWork(() -> handleButtonAction(context.player(), message.buttonID, message.x, message.y, message.z)).exceptionally(e -> {
				context.connection().disconnect(Component.literal(e.getMessage()));
				return null;
			});
		}
	}

	public static void handleButtonAction(Player entity, int buttonID, int x, int y, int z) {
		Level world = entity.level();
		// security measure to prevent arbitrary chunk generation
		if (!world.hasChunkAt(new BlockPos(x, y, z)))
			return;
		if (buttonID == 0) {

			AdventureButtonClickProcedure.execute(entity);
		}
		if (buttonID == 1) {

			CreativeButtonClickProcedure.execute(entity);
		}
		if (buttonID == 2) {

			SpectatorButtonClickProcedure.execute(entity);
		}
		if (buttonID == 3) {

			SurvivalButtonClickProcedure.execute(entity);
		}
		if (buttonID == 4) {

			ClearButtonClickProcedure.execute(entity);
		}
		if (buttonID == 5) {

			DayButtonClickProcedure.execute(world);
		}
		if (buttonID == 6) {

			NightButtonClickProcedure.execute(world);
		}
		if (buttonID == 7) {

			ThunderButtonClickProcedure.execute(world, x, y, z);
		}
		if (buttonID == 8) {

			RainyButtonClickProcedure.execute(world, x, y, z);
		}
		if (buttonID == 9) {

			ClearWeatherButtonClickProcedure.execute(world, x, y, z);
		}
		if (buttonID == 10) {

			ClearEffectButtonClickProcedure.execute(entity);
		}
		if (buttonID == 11) {

			InvisibilityEffectButtonClickProcedure.execute(entity);
		}
		if (buttonID == 12) {

			InstantHealthEffectButtonClickProcedure.execute(entity);
		}
		if (buttonID == 13) {

			KeepInventoryTrueButtonClickProcedure.execute(world, x, y, z);
		}
		if (buttonID == 14) {

			KeepInventoryFalseButtonClickProcedure.execute(world, x, y, z);
		}
		if (buttonID == 15) {

			MobSpawningTrueButtonClickProcedure.execute(world, x, y, z);
		}
		if (buttonID == 16) {

			MobSpawningFalseButtonClickProcedure.execute(world, x, y, z);
		}
		if (buttonID == 17) {

			CommondBlockOutputTrueButtonClickProcedure.execute(world, x, y, z);
		}
		if (buttonID == 18) {

			CommondBlockOutputFalseButtonClickProcedure.execute(world, x, y, z);
		}
		if (buttonID == 19) {

			SuperPickaxeButtonClickProcedure.execute(world, x, y, z);
		}
		if (buttonID == 20) {

			EnableRaidsButtonClickProcedure.execute(world, x, y, z);
		}
		if (buttonID == 21) {

			DisableRaidsButtonClickProcedure.execute(world, x, y, z);
		}
		if (buttonID == 22) {

			SuperSwordButtonClickProcedure.execute(world, x, y, z);
		}
		if (buttonID == 23) {

			WardenSpawnTrueButtonClickProcedure.execute(world, x, y, z);
		}
		if (buttonID == 24) {

			WardenSpawnFalseButtonClickProcedure.execute(world, x, y, z);
		}
		if (buttonID == 25) {

			SpawnSculkPatchButtonClickProcedure.execute(world, x, y, z);
		}
		if (buttonID == 26) {

			TickUnfreezeButtonClickProcedure.execute(world, x, y, z);
		}
		if (buttonID == 27) {

			TickFreezeButtonClickProcedure.execute(world, x, y, z);
		}
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		AdminUtilitiesMod.addNetworkMessage(AdminPanelButtonMessage.TYPE, AdminPanelButtonMessage.STREAM_CODEC, AdminPanelButtonMessage::handleData);
	}
}