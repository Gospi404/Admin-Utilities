package net.mcreator.adminutilities.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.Registry;
import net.minecraft.core.BlockPos;

public class SpawnSculkPatchButtonClickProcedure {
public static void execute(
LevelAccessor world,
double x,
double y,
double z ) {
if (world instanceof ServerLevel _level)
_level.registryAccess().registryOrThrow(Registry.CONFIGURED_FEATURE_REGISTRY)
.getHolderOrThrow(ResourceKey.create(Registry.CONFIGURED_FEATURE_REGISTRY, new ResourceLocation("sculk_patch_ancient_city"))
.value().place(_level, _level.getChunkSource().getGenerator(), _level.getRandom(), new BlockPos(x,y,z));
}
}