/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.adminutilities.init;

import org.lwjgl.glfw.GLFW;

import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.ClientRegistry;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;

import net.mcreator.adminutilities.network.AdminPanelKeyMessage;
import net.mcreator.adminutilities.AdminUtilitiesMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class AdminUtilitiesModKeyMappings {
	public static final KeyMapping ADMIN_PANEL_KEY = new KeyMapping("key.admin_utilities.admin_panel_key", GLFW.GLFW_KEY_Z, "key.categories.creative");

	@SubscribeEvent
	public static void registerKeyBindings(FMLClientSetupEvent event) {
		ClientRegistry.registerKeyBinding(ADMIN_PANEL_KEY);
	}

	@Mod.EventBusSubscriber({Dist.CLIENT})
	public static class KeyEventListener {
		@SubscribeEvent
		public static void onKeyInput(InputEvent.KeyInputEvent event) {
			if (Minecraft.getInstance().screen == null) {
				if (event.getKey() == ADMIN_PANEL_KEY.getKey().getValue()) {
					if (event.getAction() == GLFW.GLFW_PRESS) {
						AdminUtilitiesMod.PACKET_HANDLER.sendToServer(new AdminPanelKeyMessage(0, 0));
						AdminPanelKeyMessage.pressAction(Minecraft.getInstance().player, 0, 0);
					}
				}
			}
		}
	}
}