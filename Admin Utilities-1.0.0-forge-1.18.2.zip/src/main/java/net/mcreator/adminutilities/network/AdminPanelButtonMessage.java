package net.mcreator.adminutilities.network;

import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.core.BlockPos;

import net.mcreator.adminutilities.procedures.ThunderButtonClickProcedure;
import net.mcreator.adminutilities.procedures.SurvivalButtonClickProcedure;
import net.mcreator.adminutilities.procedures.SuperSwordButtonClickProcedure;
import net.mcreator.adminutilities.procedures.SuperPickaxeButtonClickProcedure;
import net.mcreator.adminutilities.procedures.SpectatorButtonClickProcedure;
import net.mcreator.adminutilities.procedures.RainyButtonClickProcedure;
import net.mcreator.adminutilities.procedures.NightButtonClickProcedure;
import net.mcreator.adminutilities.procedures.MobSpawningTrueButtonClickProcedure;
import net.mcreator.adminutilities.procedures.MobSpawningFalseButtonClickProcedure;
import net.mcreator.adminutilities.procedures.KeepInventoryTrueButtonClickProcedure;
import net.mcreator.adminutilities.procedures.KeepInventoryFalseButtonClickProcedure;
import net.mcreator.adminutilities.procedures.InvisibilityEffectButtonClickProcedure;
import net.mcreator.adminutilities.procedures.InstantHealthEffectButtonClickProcedure;
import net.mcreator.adminutilities.procedures.EnableRaidsButtonClickProcedure;
import net.mcreator.adminutilities.procedures.DisableRaidsButtonClickProcedure;
import net.mcreator.adminutilities.procedures.DayButtonClickProcedure;
import net.mcreator.adminutilities.procedures.CreativeButtonClickProcedure;
import net.mcreator.adminutilities.procedures.CommondBlockOutputTrueButtonClickProcedure;
import net.mcreator.adminutilities.procedures.CommondBlockOutputFalseButtonClickProcedure;
import net.mcreator.adminutilities.procedures.ClearWeatherButtonClickProcedure;
import net.mcreator.adminutilities.procedures.ClearEffectButtonClickProcedure;
import net.mcreator.adminutilities.procedures.ClearButtonClickProcedure;
import net.mcreator.adminutilities.procedures.AdventureButtonClickProcedure;
import net.mcreator.adminutilities.AdminUtilitiesMod;

import java.util.function.Supplier;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class AdminPanelButtonMessage {
	private final int buttonID, x, y, z;

	public AdminPanelButtonMessage(FriendlyByteBuf buffer) {
		this.buttonID = buffer.readInt();
		this.x = buffer.readInt();
		this.y = buffer.readInt();
		this.z = buffer.readInt();
	}

	public AdminPanelButtonMessage(int buttonID, int x, int y, int z) {
		this.buttonID = buttonID;
		this.x = x;
		this.y = y;
		this.z = z;
	}

	public static void buffer(AdminPanelButtonMessage message, FriendlyByteBuf buffer) {
		buffer.writeInt(message.buttonID);
		buffer.writeInt(message.x);
		buffer.writeInt(message.y);
		buffer.writeInt(message.z);
	}

	public static void handler(AdminPanelButtonMessage message, Supplier<NetworkEvent.Context> contextSupplier) {
		NetworkEvent.Context context = contextSupplier.get();
		context.enqueueWork(() -> handleButtonAction(context.getSender(), message.buttonID, message.x, message.y, message.z));
		context.setPacketHandled(true);
	}

	public static void handleButtonAction(Player entity, int buttonID, int x, int y, int z) {
		Level world = entity.level;
		// security measure to prevent arbitrary chunk generation
		if (!world.hasChunkAt(new BlockPos(x, y, z)))
			return;
		if (buttonID == 0) {

			AdventureButtonClickProcedure.execute(entity);
		}
		if (buttonID == 1) {

			CreativeButtonClickProcedure.execute(entity);
		}
		if (buttonID == 2) {

			SpectatorButtonClickProcedure.execute(entity);
		}
		if (buttonID == 3) {

			SurvivalButtonClickProcedure.execute(entity);
		}
		if (buttonID == 4) {

			ClearButtonClickProcedure.execute(entity);
		}
		if (buttonID == 5) {

			DayButtonClickProcedure.execute(world);
		}
		if (buttonID == 6) {

			NightButtonClickProcedure.execute(world);
		}
		if (buttonID == 7) {

			ThunderButtonClickProcedure.execute(world, x, y, z);
		}
		if (buttonID == 8) {

			RainyButtonClickProcedure.execute(world, x, y, z);
		}
		if (buttonID == 9) {

			ClearWeatherButtonClickProcedure.execute(world, x, y, z);
		}
		if (buttonID == 10) {

			ClearEffectButtonClickProcedure.execute(entity);
		}
		if (buttonID == 11) {

			InvisibilityEffectButtonClickProcedure.execute(entity);
		}
		if (buttonID == 12) {

			InstantHealthEffectButtonClickProcedure.execute(entity);
		}
		if (buttonID == 13) {

			KeepInventoryTrueButtonClickProcedure.execute(world, x, y, z);
		}
		if (buttonID == 14) {

			KeepInventoryFalseButtonClickProcedure.execute(world, x, y, z);
		}
		if (buttonID == 15) {

			MobSpawningTrueButtonClickProcedure.execute(world, x, y, z);
		}
		if (buttonID == 16) {

			MobSpawningFalseButtonClickProcedure.execute(world, x, y, z);
		}
		if (buttonID == 17) {

			CommondBlockOutputTrueButtonClickProcedure.execute(world, x, y, z);
		}
		if (buttonID == 18) {

			CommondBlockOutputFalseButtonClickProcedure.execute(world, x, y, z);
		}
		if (buttonID == 19) {

			SuperPickaxeButtonClickProcedure.execute(world, x, y, z);
		}
		if (buttonID == 20) {

			EnableRaidsButtonClickProcedure.execute(world, x, y, z);
		}
		if (buttonID == 21) {

			DisableRaidsButtonClickProcedure.execute(world, x, y, z);
		}
		if (buttonID == 22) {

			SuperSwordButtonClickProcedure.execute(world, x, y, z);
		}
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		AdminUtilitiesMod.addNetworkMessage(AdminPanelButtonMessage.class, AdminPanelButtonMessage::buffer, AdminPanelButtonMessage::new, AdminPanelButtonMessage::handler);
	}
}