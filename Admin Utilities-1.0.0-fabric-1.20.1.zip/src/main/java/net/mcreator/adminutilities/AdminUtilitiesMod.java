/*
 *	MCreator note:
 *
 *	If you lock base mod element files, you can edit this file and the proxy files
 *	and they won't get overwritten. If you change your mod package or modid, you
 *	need to apply these changes to this file MANUALLY.
 *
 *
 *	If you do not lock base mod element files in Workspace settings, this file
 *	will be REGENERATED on each build.
 *
 */
package net.mcreator.adminutilities;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

import net.mcreator.adminutilities.init.AdminUtilitiesModProcedures;
import net.mcreator.adminutilities.init.AdminUtilitiesModMenus;
import net.mcreator.adminutilities.init.AdminUtilitiesModKeyMappingsServer;

import net.fabricmc.api.ModInitializer;

public class AdminUtilitiesMod implements ModInitializer {
	public static final Logger LOGGER = LogManager.getLogger();
	public static final String MODID = "admin_utilities";

	@Override
	public void onInitialize() {
		LOGGER.info("Initializing AdminUtilitiesMod");

		AdminUtilitiesModProcedures.load();

		AdminUtilitiesModMenus.load();
		AdminUtilitiesModKeyMappingsServer.serverLoad();

	}
}