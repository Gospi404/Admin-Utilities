package net.mcreator.adminutilities.world.inventory;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.Container;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.core.BlockPos;

import net.mcreator.adminutilities.network.AdminPanelButtonMessage;
import net.mcreator.adminutilities.init.AdminUtilitiesModMenus;
import net.mcreator.adminutilities.AdminUtilitiesMod;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

import java.util.HashMap;

public class AdminPanelMenu extends AbstractContainerMenu {
	public final static HashMap<String, Object> guistate = new HashMap<>();
	public final Level world;
	public final Player entity;
	public int x, y, z;
	private BlockPos pos;
	private final Container inventory;
	private boolean bound = false;

	public AdminPanelMenu(int id, Inventory inv, FriendlyByteBuf extraData) {
		this(id, inv, new SimpleContainer(0));
		if (extraData != null) {
			pos = extraData.readBlockPos();
			this.x = pos.getX();
			this.y = pos.getY();
			this.z = pos.getZ();
		}
	}

	public AdminPanelMenu(int id, Inventory inv, Container container) {
		super(AdminUtilitiesModMenus.ADMIN_PANEL, id);
		this.entity = inv.player;
		this.world = inv.player.level();
		this.inventory = container;
	}

	@Override
	public boolean stillValid(Player player) {
		return this.inventory.stillValid(player);
	}

	@Override
	public ItemStack quickMoveStack(Player player, int slot) {
		return ItemStack.EMPTY;
	}

	public static void screenInit() {
		ServerPlayNetworking.registerGlobalReceiver(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_0"), AdminPanelButtonMessage::apply);
		ServerPlayNetworking.registerGlobalReceiver(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_1"), AdminPanelButtonMessage::apply);
		ServerPlayNetworking.registerGlobalReceiver(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_2"), AdminPanelButtonMessage::apply);
		ServerPlayNetworking.registerGlobalReceiver(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_3"), AdminPanelButtonMessage::apply);
		ServerPlayNetworking.registerGlobalReceiver(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_4"), AdminPanelButtonMessage::apply);
		ServerPlayNetworking.registerGlobalReceiver(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_5"), AdminPanelButtonMessage::apply);
		ServerPlayNetworking.registerGlobalReceiver(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_6"), AdminPanelButtonMessage::apply);
		ServerPlayNetworking.registerGlobalReceiver(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_7"), AdminPanelButtonMessage::apply);
		ServerPlayNetworking.registerGlobalReceiver(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_8"), AdminPanelButtonMessage::apply);
		ServerPlayNetworking.registerGlobalReceiver(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_9"), AdminPanelButtonMessage::apply);
		ServerPlayNetworking.registerGlobalReceiver(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_10"), AdminPanelButtonMessage::apply);
		ServerPlayNetworking.registerGlobalReceiver(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_11"), AdminPanelButtonMessage::apply);
		ServerPlayNetworking.registerGlobalReceiver(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_12"), AdminPanelButtonMessage::apply);
		ServerPlayNetworking.registerGlobalReceiver(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_13"), AdminPanelButtonMessage::apply);
		ServerPlayNetworking.registerGlobalReceiver(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_14"), AdminPanelButtonMessage::apply);
		ServerPlayNetworking.registerGlobalReceiver(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_15"), AdminPanelButtonMessage::apply);
		ServerPlayNetworking.registerGlobalReceiver(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_16"), AdminPanelButtonMessage::apply);
		ServerPlayNetworking.registerGlobalReceiver(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_17"), AdminPanelButtonMessage::apply);
		ServerPlayNetworking.registerGlobalReceiver(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_18"), AdminPanelButtonMessage::apply);
		ServerPlayNetworking.registerGlobalReceiver(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_19"), AdminPanelButtonMessage::apply);
		ServerPlayNetworking.registerGlobalReceiver(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_20"), AdminPanelButtonMessage::apply);
		ServerPlayNetworking.registerGlobalReceiver(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_21"), AdminPanelButtonMessage::apply);
		ServerPlayNetworking.registerGlobalReceiver(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_22"), AdminPanelButtonMessage::apply);
		ServerPlayNetworking.registerGlobalReceiver(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_23"), AdminPanelButtonMessage::apply);
		ServerPlayNetworking.registerGlobalReceiver(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_24"), AdminPanelButtonMessage::apply);
		ServerPlayNetworking.registerGlobalReceiver(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_25"), AdminPanelButtonMessage::apply);
	}
}