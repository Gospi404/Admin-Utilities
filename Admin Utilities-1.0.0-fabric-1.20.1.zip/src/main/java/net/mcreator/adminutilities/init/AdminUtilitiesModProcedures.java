/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.adminutilities.init;

import net.mcreator.adminutilities.procedures.WardenSpawnTrueButtonClickProcedure;
import net.mcreator.adminutilities.procedures.WardenSpawnFalseButtonClickProcedure;
import net.mcreator.adminutilities.procedures.ThunderButtonClickProcedure;
import net.mcreator.adminutilities.procedures.SurvivalButtonClickProcedure;
import net.mcreator.adminutilities.procedures.SuperSwordButtonClickProcedure;
import net.mcreator.adminutilities.procedures.SuperPickaxeButtonClickProcedure;
import net.mcreator.adminutilities.procedures.SpectatorButtonClickProcedure;
import net.mcreator.adminutilities.procedures.SpawnSculkPatchButtonClickProcedure;
import net.mcreator.adminutilities.procedures.RainyButtonClickProcedure;
import net.mcreator.adminutilities.procedures.NightButtonClickProcedure;
import net.mcreator.adminutilities.procedures.MobSpawningTrueButtonClickProcedure;
import net.mcreator.adminutilities.procedures.MobSpawningFalseButtonClickProcedure;
import net.mcreator.adminutilities.procedures.KeepInventoryTrueButtonClickProcedure;
import net.mcreator.adminutilities.procedures.KeepInventoryFalseButtonClickProcedure;
import net.mcreator.adminutilities.procedures.InvisibilityEffectButtonClickProcedure;
import net.mcreator.adminutilities.procedures.InstantHealthEffectButtonClickProcedure;
import net.mcreator.adminutilities.procedures.EnableRaidsButtonClickProcedure;
import net.mcreator.adminutilities.procedures.DisableRaidsButtonClickProcedure;
import net.mcreator.adminutilities.procedures.DayButtonClickProcedure;
import net.mcreator.adminutilities.procedures.CreativeButtonClickProcedure;
import net.mcreator.adminutilities.procedures.CommondBlockOutputTrueButtonClickProcedure;
import net.mcreator.adminutilities.procedures.CommondBlockOutputFalseButtonClickProcedure;
import net.mcreator.adminutilities.procedures.ClearWeatherButtonClickProcedure;
import net.mcreator.adminutilities.procedures.ClearEffectButtonClickProcedure;
import net.mcreator.adminutilities.procedures.ClearButtonClickProcedure;
import net.mcreator.adminutilities.procedures.AdventureButtonClickProcedure;
import net.mcreator.adminutilities.procedures.AdminPanelKeyPriNazhatiiKlavishiProcedure;

@SuppressWarnings("InstantiationOfUtilityClass")
public class AdminUtilitiesModProcedures {
	public static void load() {
		new AdminPanelKeyPriNazhatiiKlavishiProcedure();
		new AdventureButtonClickProcedure();
		new CreativeButtonClickProcedure();
		new SurvivalButtonClickProcedure();
		new SpectatorButtonClickProcedure();
		new ClearButtonClickProcedure();
		new DayButtonClickProcedure();
		new NightButtonClickProcedure();
		new RainyButtonClickProcedure();
		new ClearWeatherButtonClickProcedure();
		new ThunderButtonClickProcedure();
		new ClearEffectButtonClickProcedure();
		new InvisibilityEffectButtonClickProcedure();
		new InstantHealthEffectButtonClickProcedure();
		new KeepInventoryTrueButtonClickProcedure();
		new KeepInventoryFalseButtonClickProcedure();
		new MobSpawningFalseButtonClickProcedure();
		new MobSpawningTrueButtonClickProcedure();
		new SuperSwordButtonClickProcedure();
		new SuperPickaxeButtonClickProcedure();
		new DisableRaidsButtonClickProcedure();
		new EnableRaidsButtonClickProcedure();
		new CommondBlockOutputTrueButtonClickProcedure();
		new CommondBlockOutputFalseButtonClickProcedure();
		new WardenSpawnTrueButtonClickProcedure();
		new WardenSpawnFalseButtonClickProcedure();
		new SpawnSculkPatchButtonClickProcedure();
	}
}