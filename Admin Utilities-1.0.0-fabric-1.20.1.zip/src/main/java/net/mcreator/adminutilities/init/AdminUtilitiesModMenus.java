/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.adminutilities.init;

import net.minecraft.world.inventory.MenuType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;

import net.mcreator.adminutilities.world.inventory.AdminPanelMenu;
import net.mcreator.adminutilities.AdminUtilitiesMod;

import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;

public class AdminUtilitiesModMenus {
	public static MenuType<AdminPanelMenu> ADMIN_PANEL;

	public static void load() {
		ADMIN_PANEL = Registry.register(BuiltInRegistries.MENU, new ResourceLocation(AdminUtilitiesMod.MODID, "admin_panel"), new ExtendedScreenHandlerType<>(AdminPanelMenu::new));
		AdminPanelMenu.screenInit();
	}
}