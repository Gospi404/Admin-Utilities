/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.adminutilities.init;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.adminutilities.network.AdminPanelKeyMessage;
import net.mcreator.adminutilities.AdminUtilitiesMod;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

public class AdminUtilitiesModKeyMappingsServer {
	public static void serverLoad() {
		ServerPlayNetworking.registerGlobalReceiver(new ResourceLocation(AdminUtilitiesMod.MODID, "admin_panel_key"), AdminPanelKeyMessage::apply);
	}
}