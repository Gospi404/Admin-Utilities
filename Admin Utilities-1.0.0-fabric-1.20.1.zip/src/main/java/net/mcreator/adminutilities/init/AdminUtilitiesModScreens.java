/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.adminutilities.init;

import net.minecraft.client.gui.screens.MenuScreens;

import net.mcreator.adminutilities.client.gui.AdminPanelScreen;

public class AdminUtilitiesModScreens {
	public static void load() {
		MenuScreens.register(AdminUtilitiesModMenus.ADMIN_PANEL, AdminPanelScreen::new);
	}
}