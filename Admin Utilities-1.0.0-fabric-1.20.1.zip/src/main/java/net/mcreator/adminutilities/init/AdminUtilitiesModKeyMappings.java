/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.adminutilities.init;

import org.lwjgl.glfw.GLFW;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.KeyMapping;

import net.mcreator.adminutilities.network.AdminPanelKeyMessage;
import net.mcreator.adminutilities.AdminUtilitiesMod;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

import com.mojang.blaze3d.platform.InputConstants;

public class AdminUtilitiesModKeyMappings {
	public static class AdminUtilitiesModKeyMapping extends KeyMapping {
		private boolean isDownOld;

		public AdminUtilitiesModKeyMapping(String string, int i, String string2) {
			super(string, InputConstants.Type.KEYSYM, i, string2);
		}

		public int action() {
			if (isDownOld != isDown() && isDown()) {
				isDownOld = isDown();
				return 1;
			} else if (isDownOld != isDown() && !isDown()) {
				isDownOld = isDown();
				return 2;
			}
			isDownOld = isDown();
			return 0;
		}
	}

	public static AdminUtilitiesModKeyMapping ADMIN_PANEL_KEY = (AdminUtilitiesModKeyMapping) KeyBindingHelper.registerKeyBinding(new AdminUtilitiesModKeyMapping("key.admin_utilities.admin_panel_key", GLFW.GLFW_KEY_Z, "key.categories.creative"));

	public static void load() {
		ClientTickEvents.END_CLIENT_TICK.register((client) -> {
			int ADMIN_PANEL_KEYaction = ADMIN_PANEL_KEY.action();
			if (ADMIN_PANEL_KEYaction == 1) {
				ClientPlayNetworking.send(new ResourceLocation(AdminUtilitiesMod.MODID, "admin_panel_key"), new AdminPanelKeyMessage(true, false));
			} else if (ADMIN_PANEL_KEYaction == 2) {
				ClientPlayNetworking.send(new ResourceLocation(AdminUtilitiesMod.MODID, "admin_panel_key"), new AdminPanelKeyMessage(false, true));
			}
		});
	}
}