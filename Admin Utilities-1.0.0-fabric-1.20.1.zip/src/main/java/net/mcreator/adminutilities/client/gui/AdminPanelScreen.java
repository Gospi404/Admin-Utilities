package net.mcreator.adminutilities.client.gui;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.GuiGraphics;

import net.mcreator.adminutilities.world.inventory.AdminPanelMenu;
import net.mcreator.adminutilities.network.AdminPanelButtonMessage;
import net.mcreator.adminutilities.AdminUtilitiesMod;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

import java.util.HashMap;

import com.mojang.blaze3d.systems.RenderSystem;

public class AdminPanelScreen extends AbstractContainerScreen<AdminPanelMenu> {
	private final static HashMap<String, Object> guistate = AdminPanelMenu.guistate;
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	ImageButton imagebutton_adventure_button;
	ImageButton imagebutton_creative_button;
	ImageButton imagebutton_spectator_button;
	ImageButton imagebutton_survival_button;
	ImageButton imagebutton_clear_button;
	ImageButton imagebutton_day_button;
	ImageButton imagebutton_night_button;
	ImageButton imagebutton_thunder_button;
	ImageButton imagebutton_weather_button;
	ImageButton imagebutton_weather_clear_button;
	ImageButton imagebutton_clear_effect_button;
	ImageButton imagebutton_invicible_button;
	ImageButton imagebutton_effect_button;
	ImageButton imagebutton_keep_inventory_button;
	ImageButton imagebutton_no_keep_inventory_button;
	ImageButton imagebutton_spawn_mobs_button;
	ImageButton imagebutton_no_spawn_mobs_button;
	ImageButton imagebutton_command_block_button;
	ImageButton imagebutton_no_command_block_button;
	ImageButton imagebutton_pickaxe_button;
	ImageButton imagebutton_raid_omen_button;
	ImageButton imagebutton_no_raid_omen_button;
	ImageButton imagebutton_sword_button;
	ImageButton imagebutton_spawn_warden_button;
	ImageButton imagebutton_no_spawn_warden_button;
	ImageButton imagebutton_sculk_patch_button;

	public AdminPanelScreen(AdminPanelMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 176;
		this.imageHeight = 166;
	}

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		this.renderBackground(guiGraphics);
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
		if (mouseX > leftPos + 11 && mouseX < leftPos + 35 && mouseY > topPos + 11 && mouseY < topPos + 35)
			guiGraphics.renderTooltip(font, Component.translatable("gui.admin_utilities.admin_panel.tooltip_puts_you_in_adventure_mode"), mouseX, mouseY);
		if (mouseX > leftPos + 39 && mouseX < leftPos + 63 && mouseY > topPos + 11 && mouseY < topPos + 35)
			guiGraphics.renderTooltip(font, Component.translatable("gui.admin_utilities.admin_panel.tooltip_puts_you_in_creative_mode"), mouseX, mouseY);
		if (mouseX > leftPos + 67 && mouseX < leftPos + 91 && mouseY > topPos + 11 && mouseY < topPos + 35)
			guiGraphics.renderTooltip(font, Component.translatable("gui.admin_utilities.admin_panel.tooltip_puts_you_in_spectator_mode"), mouseX, mouseY);
		if (mouseX > leftPos + 95 && mouseX < leftPos + 119 && mouseY > topPos + 11 && mouseY < topPos + 35)
			guiGraphics.renderTooltip(font, Component.translatable("gui.admin_utilities.admin_panel.tooltip_puts_you_in_survival_mode"), mouseX, mouseY);
		if (mouseX > leftPos + 123 && mouseX < leftPos + 147 && mouseY > topPos + 11 && mouseY < topPos + 35)
			guiGraphics.renderTooltip(font, Component.translatable("gui.admin_utilities.admin_panel.tooltip_deletes_all_items_in_your_invent"), mouseX, mouseY);
		if (mouseX > leftPos + 11 && mouseX < leftPos + 35 && mouseY > topPos + 39 && mouseY < topPos + 63)
			guiGraphics.renderTooltip(font, Component.translatable("gui.admin_utilities.admin_panel.tooltip_changes_to_daytime"), mouseX, mouseY);
		if (mouseX > leftPos + 39 && mouseX < leftPos + 63 && mouseY > topPos + 39 && mouseY < topPos + 63)
			guiGraphics.renderTooltip(font, Component.translatable("gui.admin_utilities.admin_panel.tooltip_changes_to_night_time"), mouseX, mouseY);
		if (mouseX > leftPos + 67 && mouseX < leftPos + 91 && mouseY > topPos + 39 && mouseY < topPos + 63)
			guiGraphics.renderTooltip(font, Component.translatable("gui.admin_utilities.admin_panel.tooltip_makes_thunder_weather"), mouseX, mouseY);
		if (mouseX > leftPos + 95 && mouseX < leftPos + 119 && mouseY > topPos + 39 && mouseY < topPos + 63)
			guiGraphics.renderTooltip(font, Component.translatable("gui.admin_utilities.admin_panel.tooltip_makes_rainysnowy_weather"), mouseX, mouseY);
		if (mouseX > leftPos + 123 && mouseX < leftPos + 147 && mouseY > topPos + 39 && mouseY < topPos + 63)
			guiGraphics.renderTooltip(font, Component.translatable("gui.admin_utilities.admin_panel.tooltip_makes_the_weather_clear"), mouseX, mouseY);
		if (mouseX > leftPos + 11 && mouseX < leftPos + 35 && mouseY > topPos + 67 && mouseY < topPos + 91)
			guiGraphics.renderTooltip(font, Component.translatable("gui.admin_utilities.admin_panel.tooltip_removes_all_effects_from_you"), mouseX, mouseY);
		if (mouseX > leftPos + 39 && mouseX < leftPos + 63 && mouseY > topPos + 67 && mouseY < topPos + 91)
			guiGraphics.renderTooltip(font, Component.translatable("gui.admin_utilities.admin_panel.tooltip_gives_the_effect_of_invisibility"), mouseX, mouseY);
		if (mouseX > leftPos + 67 && mouseX < leftPos + 91 && mouseY > topPos + 67 && mouseY < topPos + 91)
			guiGraphics.renderTooltip(font, Component.translatable("gui.admin_utilities.admin_panel.tooltip_restores_all_your_health"), mouseX, mouseY);
		if (mouseX > leftPos + 95 && mouseX < leftPos + 119 && mouseY > topPos + 67 && mouseY < topPos + 91)
			guiGraphics.renderTooltip(font, Component.translatable("gui.admin_utilities.admin_panel.tooltip_saves_everyones_inventory_after"), mouseX, mouseY);
		if (mouseX > leftPos + 123 && mouseX < leftPos + 147 && mouseY > topPos + 67 && mouseY < topPos + 91)
			guiGraphics.renderTooltip(font, Component.translatable("gui.admin_utilities.admin_panel.tooltip_does_not_save_all_inventory_afte"), mouseX, mouseY);
		if (mouseX > leftPos + 11 && mouseX < leftPos + 35 && mouseY > topPos + 95 && mouseY < topPos + 119)
			guiGraphics.renderTooltip(font, Component.translatable("gui.admin_utilities.admin_panel.tooltip_includes_the_natural_appearance"), mouseX, mouseY);
		if (mouseX > leftPos + 39 && mouseX < leftPos + 63 && mouseY > topPos + 95 && mouseY < topPos + 119)
			guiGraphics.renderTooltip(font, Component.translatable("gui.admin_utilities.admin_panel.tooltip_disables_the_natural_appearance"), mouseX, mouseY);
		if (mouseX > leftPos + 67 && mouseX < leftPos + 91 && mouseY > topPos + 95 && mouseY < topPos + 119)
			guiGraphics.renderTooltip(font, Component.translatable("gui.admin_utilities.admin_panel.tooltip_gives_you_a_super_pickaxe"), mouseX, mouseY);
		if (mouseX > leftPos + 67 && mouseX < leftPos + 91 && mouseY > topPos + 123 && mouseY < topPos + 147)
			guiGraphics.renderTooltip(font, Component.translatable("gui.admin_utilities.admin_panel.tooltip_gives_you_a_super_sword"), mouseX, mouseY);
		if (mouseX > leftPos + 95 && mouseX < leftPos + 119 && mouseY > topPos + 96 && mouseY < topPos + 120)
			guiGraphics.renderTooltip(font, Component.translatable("gui.admin_utilities.admin_panel.tooltip_enables_command_output_of_the_co"), mouseX, mouseY);
		if (mouseX > leftPos + 123 && mouseX < leftPos + 147 && mouseY > topPos + 95 && mouseY < topPos + 119)
			guiGraphics.renderTooltip(font, Component.translatable("gui.admin_utilities.admin_panel.tooltip_disables_command_output_of_the_c"), mouseX, mouseY);
		if (mouseX > leftPos + 11 && mouseX < leftPos + 35 && mouseY > topPos + 123 && mouseY < topPos + 147)
			guiGraphics.renderTooltip(font, Component.translatable("gui.admin_utilities.admin_panel.tooltip_includes_village_raids_in_the_wo"), mouseX, mouseY);
		if (mouseX > leftPos + 39 && mouseX < leftPos + 63 && mouseY > topPos + 124 && mouseY < topPos + 148)
			guiGraphics.renderTooltip(font, Component.translatable("gui.admin_utilities.admin_panel.tooltip_turns_off_village_raids_in_the_w"), mouseX, mouseY);
		if (mouseX > leftPos + 151 && mouseX < leftPos + 175 && mouseY > topPos + 11 && mouseY < topPos + 35)
			guiGraphics.renderTooltip(font, Component.translatable("gui.admin_utilities.admin_panel.tooltip_summon_the_sculk_patch"), mouseX, mouseY);
		if (mouseX > leftPos + 95 && mouseX < leftPos + 119 && mouseY > topPos + 123 && mouseY < topPos + 147)
			guiGraphics.renderTooltip(font, Component.translatable("gui.admin_utilities.admin_panel.tooltip_turns_on_the_appearance_of_the_w"), mouseX, mouseY);
		if (mouseX > leftPos + 123 && mouseX < leftPos + 147 && mouseY > topPos + 123 && mouseY < topPos + 147)
			guiGraphics.renderTooltip(font, Component.translatable("gui.admin_utilities.admin_panel.tooltip_turns_off_the_appearance_of_the"), mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int gx, int gy) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	public void containerTick() {
		super.containerTick();
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		guiGraphics.drawString(this.font, Component.translatable("gui.admin_utilities.admin_panel.label_admin_panel"), 10, -3, -1, false);
	}

	@Override
	public void onClose() {
		super.onClose();
	}

	@Override
	public void init() {
		super.init();
		imagebutton_adventure_button = new ImageButton(this.leftPos + 13, this.topPos + 13, 20, 20, 0, 0, 20, new ResourceLocation("admin_utilities:textures/screens/atlas/imagebutton_adventure_button.png"), 20, 40, e -> {
			if (true) {
				ClientPlayNetworking.send(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_0"), new AdminPanelButtonMessage(0, x, y, z));
			}
		});
		guistate.put("button:imagebutton_adventure_button", imagebutton_adventure_button);
		this.addRenderableWidget(imagebutton_adventure_button);
		imagebutton_creative_button = new ImageButton(this.leftPos + 41, this.topPos + 13, 20, 20, 0, 0, 20, new ResourceLocation("admin_utilities:textures/screens/atlas/imagebutton_creative_button.png"), 20, 40, e -> {
			if (true) {
				ClientPlayNetworking.send(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_1"), new AdminPanelButtonMessage(1, x, y, z));
			}
		});
		guistate.put("button:imagebutton_creative_button", imagebutton_creative_button);
		this.addRenderableWidget(imagebutton_creative_button);
		imagebutton_spectator_button = new ImageButton(this.leftPos + 69, this.topPos + 13, 20, 20, 0, 0, 20, new ResourceLocation("admin_utilities:textures/screens/atlas/imagebutton_spectator_button.png"), 20, 40, e -> {
			if (true) {
				ClientPlayNetworking.send(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_2"), new AdminPanelButtonMessage(2, x, y, z));
			}
		});
		guistate.put("button:imagebutton_spectator_button", imagebutton_spectator_button);
		this.addRenderableWidget(imagebutton_spectator_button);
		imagebutton_survival_button = new ImageButton(this.leftPos + 97, this.topPos + 13, 20, 20, 0, 0, 20, new ResourceLocation("admin_utilities:textures/screens/atlas/imagebutton_survival_button.png"), 20, 40, e -> {
			if (true) {
				ClientPlayNetworking.send(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_3"), new AdminPanelButtonMessage(3, x, y, z));
			}
		});
		guistate.put("button:imagebutton_survival_button", imagebutton_survival_button);
		this.addRenderableWidget(imagebutton_survival_button);
		imagebutton_clear_button = new ImageButton(this.leftPos + 125, this.topPos + 13, 20, 20, 0, 0, 20, new ResourceLocation("admin_utilities:textures/screens/atlas/imagebutton_clear_button.png"), 20, 40, e -> {
			if (true) {
				ClientPlayNetworking.send(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_4"), new AdminPanelButtonMessage(4, x, y, z));
			}
		});
		guistate.put("button:imagebutton_clear_button", imagebutton_clear_button);
		this.addRenderableWidget(imagebutton_clear_button);
		imagebutton_day_button = new ImageButton(this.leftPos + 13, this.topPos + 41, 20, 20, 0, 0, 20, new ResourceLocation("admin_utilities:textures/screens/atlas/imagebutton_day_button.png"), 20, 40, e -> {
			if (true) {
				ClientPlayNetworking.send(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_5"), new AdminPanelButtonMessage(5, x, y, z));
			}
		});
		guistate.put("button:imagebutton_day_button", imagebutton_day_button);
		this.addRenderableWidget(imagebutton_day_button);
		imagebutton_night_button = new ImageButton(this.leftPos + 41, this.topPos + 41, 20, 20, 0, 0, 20, new ResourceLocation("admin_utilities:textures/screens/atlas/imagebutton_night_button.png"), 20, 40, e -> {
			if (true) {
				ClientPlayNetworking.send(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_6"), new AdminPanelButtonMessage(6, x, y, z));
			}
		});
		guistate.put("button:imagebutton_night_button", imagebutton_night_button);
		this.addRenderableWidget(imagebutton_night_button);
		imagebutton_thunder_button = new ImageButton(this.leftPos + 69, this.topPos + 41, 20, 20, 0, 0, 20, new ResourceLocation("admin_utilities:textures/screens/atlas/imagebutton_thunder_button.png"), 20, 40, e -> {
			if (true) {
				ClientPlayNetworking.send(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_7"), new AdminPanelButtonMessage(7, x, y, z));
			}
		});
		guistate.put("button:imagebutton_thunder_button", imagebutton_thunder_button);
		this.addRenderableWidget(imagebutton_thunder_button);
		imagebutton_weather_button = new ImageButton(this.leftPos + 97, this.topPos + 41, 20, 20, 0, 0, 20, new ResourceLocation("admin_utilities:textures/screens/atlas/imagebutton_weather_button.png"), 20, 40, e -> {
			if (true) {
				ClientPlayNetworking.send(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_8"), new AdminPanelButtonMessage(8, x, y, z));
			}
		});
		guistate.put("button:imagebutton_weather_button", imagebutton_weather_button);
		this.addRenderableWidget(imagebutton_weather_button);
		imagebutton_weather_clear_button = new ImageButton(this.leftPos + 125, this.topPos + 41, 20, 20, 0, 0, 20, new ResourceLocation("admin_utilities:textures/screens/atlas/imagebutton_weather_clear_button.png"), 20, 40, e -> {
			if (true) {
				ClientPlayNetworking.send(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_9"), new AdminPanelButtonMessage(9, x, y, z));
			}
		});
		guistate.put("button:imagebutton_weather_clear_button", imagebutton_weather_clear_button);
		this.addRenderableWidget(imagebutton_weather_clear_button);
		imagebutton_clear_effect_button = new ImageButton(this.leftPos + 13, this.topPos + 69, 20, 20, 0, 0, 20, new ResourceLocation("admin_utilities:textures/screens/atlas/imagebutton_clear_effect_button.png"), 20, 40, e -> {
			if (true) {
				ClientPlayNetworking.send(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_10"), new AdminPanelButtonMessage(10, x, y, z));
			}
		});
		guistate.put("button:imagebutton_clear_effect_button", imagebutton_clear_effect_button);
		this.addRenderableWidget(imagebutton_clear_effect_button);
		imagebutton_invicible_button = new ImageButton(this.leftPos + 41, this.topPos + 69, 20, 20, 0, 0, 20, new ResourceLocation("admin_utilities:textures/screens/atlas/imagebutton_invicible_button.png"), 20, 40, e -> {
			if (true) {
				ClientPlayNetworking.send(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_11"), new AdminPanelButtonMessage(11, x, y, z));
			}
		});
		guistate.put("button:imagebutton_invicible_button", imagebutton_invicible_button);
		this.addRenderableWidget(imagebutton_invicible_button);
		imagebutton_effect_button = new ImageButton(this.leftPos + 69, this.topPos + 69, 20, 20, 0, 0, 20, new ResourceLocation("admin_utilities:textures/screens/atlas/imagebutton_effect_button.png"), 20, 40, e -> {
			if (true) {
				ClientPlayNetworking.send(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_12"), new AdminPanelButtonMessage(12, x, y, z));
			}
		});
		guistate.put("button:imagebutton_effect_button", imagebutton_effect_button);
		this.addRenderableWidget(imagebutton_effect_button);
		imagebutton_keep_inventory_button = new ImageButton(this.leftPos + 97, this.topPos + 69, 20, 20, 0, 0, 20, new ResourceLocation("admin_utilities:textures/screens/atlas/imagebutton_keep_inventory_button.png"), 20, 40, e -> {
			if (true) {
				ClientPlayNetworking.send(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_13"), new AdminPanelButtonMessage(13, x, y, z));
			}
		});
		guistate.put("button:imagebutton_keep_inventory_button", imagebutton_keep_inventory_button);
		this.addRenderableWidget(imagebutton_keep_inventory_button);
		imagebutton_no_keep_inventory_button = new ImageButton(this.leftPos + 125, this.topPos + 69, 20, 20, 0, 0, 20, new ResourceLocation("admin_utilities:textures/screens/atlas/imagebutton_no_keep_inventory_button.png"), 20, 40, e -> {
			if (true) {
				ClientPlayNetworking.send(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_14"), new AdminPanelButtonMessage(14, x, y, z));
			}
		});
		guistate.put("button:imagebutton_no_keep_inventory_button", imagebutton_no_keep_inventory_button);
		this.addRenderableWidget(imagebutton_no_keep_inventory_button);
		imagebutton_spawn_mobs_button = new ImageButton(this.leftPos + 13, this.topPos + 97, 20, 20, 0, 0, 20, new ResourceLocation("admin_utilities:textures/screens/atlas/imagebutton_spawn_mobs_button.png"), 20, 40, e -> {
			if (true) {
				ClientPlayNetworking.send(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_15"), new AdminPanelButtonMessage(15, x, y, z));
			}
		});
		guistate.put("button:imagebutton_spawn_mobs_button", imagebutton_spawn_mobs_button);
		this.addRenderableWidget(imagebutton_spawn_mobs_button);
		imagebutton_no_spawn_mobs_button = new ImageButton(this.leftPos + 41, this.topPos + 97, 20, 20, 0, 0, 20, new ResourceLocation("admin_utilities:textures/screens/atlas/imagebutton_no_spawn_mobs_button.png"), 20, 40, e -> {
			if (true) {
				ClientPlayNetworking.send(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_16"), new AdminPanelButtonMessage(16, x, y, z));
			}
		});
		guistate.put("button:imagebutton_no_spawn_mobs_button", imagebutton_no_spawn_mobs_button);
		this.addRenderableWidget(imagebutton_no_spawn_mobs_button);
		imagebutton_command_block_button = new ImageButton(this.leftPos + 97, this.topPos + 97, 20, 20, 0, 0, 20, new ResourceLocation("admin_utilities:textures/screens/atlas/imagebutton_command_block_button.png"), 20, 40, e -> {
			if (true) {
				ClientPlayNetworking.send(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_17"), new AdminPanelButtonMessage(17, x, y, z));
			}
		});
		guistate.put("button:imagebutton_command_block_button", imagebutton_command_block_button);
		this.addRenderableWidget(imagebutton_command_block_button);
		imagebutton_no_command_block_button = new ImageButton(this.leftPos + 125, this.topPos + 97, 20, 20, 0, 0, 20, new ResourceLocation("admin_utilities:textures/screens/atlas/imagebutton_no_command_block_button.png"), 20, 40, e -> {
			if (true) {
				ClientPlayNetworking.send(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_18"), new AdminPanelButtonMessage(18, x, y, z));
			}
		});
		guistate.put("button:imagebutton_no_command_block_button", imagebutton_no_command_block_button);
		this.addRenderableWidget(imagebutton_no_command_block_button);
		imagebutton_pickaxe_button = new ImageButton(this.leftPos + 69, this.topPos + 97, 20, 20, 0, 0, 20, new ResourceLocation("admin_utilities:textures/screens/atlas/imagebutton_pickaxe_button.png"), 20, 40, e -> {
			if (true) {
				ClientPlayNetworking.send(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_19"), new AdminPanelButtonMessage(19, x, y, z));
			}
		});
		guistate.put("button:imagebutton_pickaxe_button", imagebutton_pickaxe_button);
		this.addRenderableWidget(imagebutton_pickaxe_button);
		imagebutton_raid_omen_button = new ImageButton(this.leftPos + 13, this.topPos + 125, 20, 20, 0, 0, 20, new ResourceLocation("admin_utilities:textures/screens/atlas/imagebutton_raid_omen_button.png"), 20, 40, e -> {
			if (true) {
				ClientPlayNetworking.send(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_20"), new AdminPanelButtonMessage(20, x, y, z));
			}
		});
		guistate.put("button:imagebutton_raid_omen_button", imagebutton_raid_omen_button);
		this.addRenderableWidget(imagebutton_raid_omen_button);
		imagebutton_no_raid_omen_button = new ImageButton(this.leftPos + 41, this.topPos + 125, 20, 20, 0, 0, 20, new ResourceLocation("admin_utilities:textures/screens/atlas/imagebutton_no_raid_omen_button.png"), 20, 40, e -> {
			if (true) {
				ClientPlayNetworking.send(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_21"), new AdminPanelButtonMessage(21, x, y, z));
			}
		});
		guistate.put("button:imagebutton_no_raid_omen_button", imagebutton_no_raid_omen_button);
		this.addRenderableWidget(imagebutton_no_raid_omen_button);
		imagebutton_sword_button = new ImageButton(this.leftPos + 69, this.topPos + 125, 20, 20, 0, 0, 20, new ResourceLocation("admin_utilities:textures/screens/atlas/imagebutton_sword_button.png"), 20, 40, e -> {
			if (true) {
				ClientPlayNetworking.send(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_22"), new AdminPanelButtonMessage(22, x, y, z));
			}
		});
		guistate.put("button:imagebutton_sword_button", imagebutton_sword_button);
		this.addRenderableWidget(imagebutton_sword_button);
		imagebutton_spawn_warden_button = new ImageButton(this.leftPos + 97, this.topPos + 125, 20, 20, 0, 0, 20, new ResourceLocation("admin_utilities:textures/screens/atlas/imagebutton_spawn_warden_button.png"), 20, 40, e -> {
			if (true) {
				ClientPlayNetworking.send(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_23"), new AdminPanelButtonMessage(23, x, y, z));
			}
		});
		guistate.put("button:imagebutton_spawn_warden_button", imagebutton_spawn_warden_button);
		this.addRenderableWidget(imagebutton_spawn_warden_button);
		imagebutton_no_spawn_warden_button = new ImageButton(this.leftPos + 125, this.topPos + 125, 20, 20, 0, 0, 20, new ResourceLocation("admin_utilities:textures/screens/atlas/imagebutton_no_spawn_warden_button.png"), 20, 40, e -> {
			if (true) {
				ClientPlayNetworking.send(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_24"), new AdminPanelButtonMessage(24, x, y, z));
			}
		});
		guistate.put("button:imagebutton_no_spawn_warden_button", imagebutton_no_spawn_warden_button);
		this.addRenderableWidget(imagebutton_no_spawn_warden_button);
		imagebutton_sculk_patch_button = new ImageButton(this.leftPos + 153, this.topPos + 13, 20, 20, 0, 0, 20, new ResourceLocation("admin_utilities:textures/screens/atlas/imagebutton_sculk_patch_button.png"), 20, 40, e -> {
			if (true) {
				ClientPlayNetworking.send(new ResourceLocation(AdminUtilitiesMod.MODID, "adminpanel_button_25"), new AdminPanelButtonMessage(25, x, y, z));
			}
		});
		guistate.put("button:imagebutton_sculk_patch_button", imagebutton_sculk_patch_button);
		this.addRenderableWidget(imagebutton_sculk_patch_button);
	}
}