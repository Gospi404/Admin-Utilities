package net.mcreator.adminutilities.network;

import net.minecraft.world.level.Level;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.network.FriendlyByteBuf;

import net.mcreator.adminutilities.world.inventory.AdminPanelMenu;
import net.mcreator.adminutilities.procedures.WardenSpawnTrueButtonClickProcedure;
import net.mcreator.adminutilities.procedures.WardenSpawnFalseButtonClickProcedure;
import net.mcreator.adminutilities.procedures.ThunderButtonClickProcedure;
import net.mcreator.adminutilities.procedures.SurvivalButtonClickProcedure;
import net.mcreator.adminutilities.procedures.SuperSwordButtonClickProcedure;
import net.mcreator.adminutilities.procedures.SuperPickaxeButtonClickProcedure;
import net.mcreator.adminutilities.procedures.SpectatorButtonClickProcedure;
import net.mcreator.adminutilities.procedures.SpawnSculkPatchButtonClickProcedure;
import net.mcreator.adminutilities.procedures.RainyButtonClickProcedure;
import net.mcreator.adminutilities.procedures.NightButtonClickProcedure;
import net.mcreator.adminutilities.procedures.MobSpawningTrueButtonClickProcedure;
import net.mcreator.adminutilities.procedures.MobSpawningFalseButtonClickProcedure;
import net.mcreator.adminutilities.procedures.KeepInventoryTrueButtonClickProcedure;
import net.mcreator.adminutilities.procedures.KeepInventoryFalseButtonClickProcedure;
import net.mcreator.adminutilities.procedures.InvisibilityEffectButtonClickProcedure;
import net.mcreator.adminutilities.procedures.InstantHealthEffectButtonClickProcedure;
import net.mcreator.adminutilities.procedures.EnableRaidsButtonClickProcedure;
import net.mcreator.adminutilities.procedures.DisableRaidsButtonClickProcedure;
import net.mcreator.adminutilities.procedures.DayButtonClickProcedure;
import net.mcreator.adminutilities.procedures.CreativeButtonClickProcedure;
import net.mcreator.adminutilities.procedures.CommondBlockOutputTrueButtonClickProcedure;
import net.mcreator.adminutilities.procedures.CommondBlockOutputFalseButtonClickProcedure;
import net.mcreator.adminutilities.procedures.ClearWeatherButtonClickProcedure;
import net.mcreator.adminutilities.procedures.ClearEffectButtonClickProcedure;
import net.mcreator.adminutilities.procedures.ClearButtonClickProcedure;
import net.mcreator.adminutilities.procedures.AdventureButtonClickProcedure;

import net.fabricmc.fabric.api.networking.v1.PacketSender;

import java.util.HashMap;

import io.netty.buffer.Unpooled;

public class AdminPanelButtonMessage extends FriendlyByteBuf {
	public AdminPanelButtonMessage(int buttonID, int x, int y, int z) {
		super(Unpooled.buffer());
		writeInt(buttonID);
		writeInt(x);
		writeInt(y);
		writeInt(z);
	}

	public static void apply(MinecraftServer server, ServerPlayer entity, ServerGamePacketListenerImpl handler, FriendlyByteBuf buf, PacketSender responseSender) {
		int buttonID = buf.readInt();
		double x = buf.readInt();
		double y = buf.readInt();
		double z = buf.readInt();
		server.execute(() -> {
			Level world = entity.level();
			HashMap guistate = AdminPanelMenu.guistate;
			if (buttonID == 0) {

				AdventureButtonClickProcedure.execute(entity);
			}
			if (buttonID == 1) {

				CreativeButtonClickProcedure.execute(entity);
			}
			if (buttonID == 2) {

				SpectatorButtonClickProcedure.execute(entity);
			}
			if (buttonID == 3) {

				SurvivalButtonClickProcedure.execute(entity);
			}
			if (buttonID == 4) {

				ClearButtonClickProcedure.execute(entity);
			}
			if (buttonID == 5) {

				DayButtonClickProcedure.execute(world);
			}
			if (buttonID == 6) {

				NightButtonClickProcedure.execute(world);
			}
			if (buttonID == 7) {

				ThunderButtonClickProcedure.execute(world, x, y, z);
			}
			if (buttonID == 8) {

				RainyButtonClickProcedure.execute(world, x, y, z);
			}
			if (buttonID == 9) {

				ClearWeatherButtonClickProcedure.execute(world, x, y, z);
			}
			if (buttonID == 10) {

				ClearEffectButtonClickProcedure.execute(entity);
			}
			if (buttonID == 11) {

				InvisibilityEffectButtonClickProcedure.execute(entity);
			}
			if (buttonID == 12) {

				InstantHealthEffectButtonClickProcedure.execute(entity);
			}
			if (buttonID == 13) {

				KeepInventoryTrueButtonClickProcedure.execute(world, x, y, z);
			}
			if (buttonID == 14) {

				KeepInventoryFalseButtonClickProcedure.execute(world, x, y, z);
			}
			if (buttonID == 15) {

				MobSpawningTrueButtonClickProcedure.execute(world, x, y, z);
			}
			if (buttonID == 16) {

				MobSpawningFalseButtonClickProcedure.execute(world, x, y, z);
			}
			if (buttonID == 17) {

				CommondBlockOutputTrueButtonClickProcedure.execute(world, x, y, z);
			}
			if (buttonID == 18) {

				CommondBlockOutputFalseButtonClickProcedure.execute(world, x, y, z);
			}
			if (buttonID == 19) {

				SuperPickaxeButtonClickProcedure.execute(world, x, y, z);
			}
			if (buttonID == 20) {

				EnableRaidsButtonClickProcedure.execute(world, x, y, z);
			}
			if (buttonID == 21) {

				DisableRaidsButtonClickProcedure.execute(world, x, y, z);
			}
			if (buttonID == 22) {

				SuperSwordButtonClickProcedure.execute(world, x, y, z);
			}
			if (buttonID == 23) {

				WardenSpawnTrueButtonClickProcedure.execute(world, x, y, z);
			}
			if (buttonID == 24) {

				WardenSpawnFalseButtonClickProcedure.execute(world, x, y, z);
			}
			if (buttonID == 25) {

				SpawnSculkPatchButtonClickProcedure.execute(world, x, y, z);
			}
		});
	}
}